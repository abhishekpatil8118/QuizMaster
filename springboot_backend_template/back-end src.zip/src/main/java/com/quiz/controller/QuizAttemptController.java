package com.quiz.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.quiz.dto.AdminAttemptResponseDto;
import com.quiz.dto.AnswerRequestDto;
import com.quiz.dto.QuizResultResponseDto;
import com.quiz.dto.StartAttemptRequestDto;
import com.quiz.entity.Question;
import com.quiz.entity.UserAnswer;
import com.quiz.service.QuizAttemptService;

@RestController
@RequestMapping("/attempt")
@CrossOrigin(origins = "http://localhost:5173")
public class QuizAttemptController {

    private final QuizAttemptService quizAttemptService;

    public QuizAttemptController(QuizAttemptService quizAttemptService) {
        this.quizAttemptService = quizAttemptService;
    }

    /**
     * START QUIZ
     * Accepts JSON and returns only attemptId
     */
    @PostMapping("/start")
    public Long startQuiz(@RequestBody StartAttemptRequestDto request) {

        return quizAttemptService
                .startQuiz(request.getUserId(), request.getQuizId())
                .getId();
    }

    /**
     * SUBMIT QUIZ
     * Accepts answers and returns result DTO
     */
    @PostMapping("/{attemptId}/submit")
    public QuizResultResponseDto submitQuiz(
            @PathVariable Long attemptId,
            @RequestBody List<AnswerRequestDto> answers) {

        List<UserAnswer> userAnswers = new ArrayList<>();

        for (AnswerRequestDto dto : answers) {
            UserAnswer ua = new UserAnswer();

            Question question = new Question();
            question.setId(dto.getQuestionId());

            ua.setQuestion(question);
            ua.setSelectedOption(dto.getSelectedAnswer());

            userAnswers.add(ua);
        }

        return quizAttemptService.submitQuiz(attemptId, userAnswers);
    }
    
    // ADMIN: see all quiz attempts
    @GetMapping("/attempts")
    public List<AdminAttemptResponseDto> getAllAttempts() {
        return quizAttemptService.getAllAttemptsForAdmin();
    }
}
