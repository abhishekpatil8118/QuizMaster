package com.quiz.entity;

public enum Role {
    ADMIN,
    USER
}
