package com.quiz.controller;

import com.quiz.entity.Question;
import com.quiz.entity.Quiz;
import com.quiz.service.QuizService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/quizzes")
@CrossOrigin(origins = "http://localhost:5173")
public class QuizController {

    private final QuizService quizService;

    public QuizController(QuizService quizService) {
        this.quizService = quizService;
    }

    // ================= ADMIN =================

    // Create a quiz
    @PostMapping("/admin/create")
    public Quiz createQuiz(@RequestBody Quiz quiz) {
        return quizService.createQuiz(quiz);
    }

    // ================= USER =================

    // Get all quizzes (for quiz list page)
    @GetMapping
    public List<Quiz> getAllQuizzes() {
        return quizService.getAllQuizzes();
    }

    // Start quiz → fetch questions
    @GetMapping("/{quizId}/start")
    public List<Question> startQuiz(@PathVariable Long quizId) {
        return quizService.startQuiz(quizId);
    }
}
