package com.quiz.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.quiz.dto.AdminAttemptResponseDto;
import com.quiz.dto.QuizResultResponseDto;
import com.quiz.entity.Question;
import com.quiz.entity.Quiz;
import com.quiz.entity.QuizAttempt;
import com.quiz.entity.User;
import com.quiz.entity.UserAnswer;
import com.quiz.repository.QuestionRepository;
import com.quiz.repository.QuizAttemptRepository;
import com.quiz.repository.QuizRepository;
import com.quiz.repository.UserAnswerRepository;
import com.quiz.repository.UserRepository;

@Service
public class QuizAttemptServiceImpl implements QuizAttemptService {

    private final QuizAttemptRepository quizAttemptRepository;
    private final UserRepository userRepository;
    private final QuizRepository quizRepository;
    private final QuestionRepository questionRepository;
    private final UserAnswerRepository userAnswerRepository;

    public QuizAttemptServiceImpl(
            QuizAttemptRepository quizAttemptRepository,
            UserRepository userRepository,
            QuizRepository quizRepository,
            QuestionRepository questionRepository,
            UserAnswerRepository userAnswerRepository) {

        this.quizAttemptRepository = quizAttemptRepository;
        this.userRepository = userRepository;
        this.quizRepository = quizRepository;
        this.questionRepository = questionRepository;
        this.userAnswerRepository = userAnswerRepository;
    }

    @Override
    public QuizAttempt startQuiz(Long userId, Long quizId) {

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Quiz quiz = quizRepository.findById(quizId)
                .orElseThrow(() -> new RuntimeException("Quiz not found"));

        QuizAttempt attempt = new QuizAttempt();
        attempt.setUser(user);
        attempt.setQuiz(quiz);
        attempt.setScore(0);
        attempt.setSubmittedAt(LocalDateTime.now());

        return quizAttemptRepository.save(attempt);
    }

    @Override
    public QuizResultResponseDto submitQuiz(Long attemptId, List<UserAnswer> answers) {

        QuizAttempt attempt = quizAttemptRepository.findById(attemptId)
                .orElseThrow(() -> new RuntimeException("Attempt not found"));

        int score = 0;

        for (UserAnswer answer : answers) {

            Question question = questionRepository.findById(
                    answer.getQuestion().getId()
            ).orElseThrow(() -> new RuntimeException("Question not found"));

            if (question.getCorrectAnswer()
                    .equalsIgnoreCase(answer.getSelectedOption())) {
                score++;
            }

            answer.setQuizAttempt(attempt);
        }

        userAnswerRepository.saveAll(answers);

        attempt.setScore(score);
        attempt.setSubmittedAt(LocalDateTime.now());

        quizAttemptRepository.save(attempt);

        //  MAP ENTITY → DTO (THIS IS THE FIX)
        return new QuizResultResponseDto(
                attempt.getId(),
                score,
                answers.size()
        );
    }
    
    @Override
    public List<AdminAttemptResponseDto> getAllAttemptsForAdmin() {

        List<QuizAttempt> attempts = quizAttemptRepository.findAll();

        return attempts.stream()
                .map(a -> new AdminAttemptResponseDto(
                        a.getId(),
                        a.getUser().getUsername(),
                        a.getQuiz().getTitle(),
                        a.getScore(),
                        a.getQuiz().getTotalQuestions(),
                        a.getSubmittedAt()
                ))
                .collect(Collectors.toList());
    }
}
