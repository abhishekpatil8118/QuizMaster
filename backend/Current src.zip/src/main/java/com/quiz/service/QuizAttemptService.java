package com.quiz.service;

import java.util.List;

import com.quiz.dto.AdminAttemptResponseDto;
import com.quiz.dto.QuizResultResponseDto;
import com.quiz.entity.QuizAttempt;
import com.quiz.entity.UserAnswer;

public interface QuizAttemptService {

	QuizAttempt startQuiz(Long userId, Long quizId);

	QuizResultResponseDto submitQuiz(Long attemptId, List<UserAnswer> answers);
	
	List<AdminAttemptResponseDto> getAllAttemptsForAdmin();
}
